import React, { useEffect, useState } from 'react'

const Rating = ({iniialRating, onRate}) => {
  const [rating, setRating] = useState(iniialRating || 0)
  const handleRating = (value) =>{
    setRating(value);
    if(onRate) onRate(value)
  }
useEffect(()=>{
 if (iniialRating) {
  setRating(iniialRating)
 }
},[iniialRating])
  return (
    <div>
      {Array.from({length: 5},(_,index)=>{
      const startValue = index + 1;
      return (
        <span key={index} className={`text-xl sm:text-2xl cursor-pointer
         transition-colors ${startValue <= rating ? 'text-yellow-500': 'text-gray-400'}`} onClick={()=>handleRating(startValue)}>
         ★
        </span>
      )
       })}
    </div>
  )
}

export default Rating