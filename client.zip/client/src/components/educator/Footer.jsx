import React from 'react'

const Footer = () => {
  return (
    <div>
        <h1>Edu Footer</h1>

    </div>
  )
}

export default Footer