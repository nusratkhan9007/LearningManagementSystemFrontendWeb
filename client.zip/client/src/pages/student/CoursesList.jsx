// import React, { useContext } from 'react'
// import SearchBar from '../../components/student/SearchBar'
// import {AppContext} from '../../context/AppContext'

// import { useParams } from 'react-router-dom'
// import CourseCard from '../../components/student/CourseCard'
// const CoursesList = () => {

//   const {navigate,allCourses} = useContext(AppContext)
//   const {input} =  useParams()

//   const [filteredCourse, setFilterCourse] = useState([])
//   useEffect(()=>{
//     if(allCourses && allCourses.length > 0 ){
//       const tempCouses = allCourses.slice()
//       input ? 
//        setFilterCourse(
//         tempCouses.filter(item => item.courseTitle.toLowerCase().includes(input.toLowerCase)
      
//       )
//        )
//       : setFilterCourse(tempCouses)
//     }

//   },[allCourses,input])

//   return (
//    <>
//    <div className='relative md:px-36 px-8 pt-20 text-left'>
//     <div className='flex md:flex-row flex-col gap-6 items-start justify-between w-full'>
//       <div>
//        <h1 className='text-4xl font-semibold text-gray-800'>Course List</h1>
//        <p className='text-gray-500'>
//        <span className='text-blue-600 cursor-pointer' 
//        onClick={()=>navigate('/')}> Home </span> / 
//        <span>Course List</span></p> 
//       </div>
//       <SearchBar data={input}/>
//     </div>
//     <div>
//       {filteredCourses.map((course, index)=><CourseCard key = {index}/>)}
//     </div>
//    </div>
//    </>
//   )
// }

// export default CoursesList


import React, { useContext, useState, useEffect } from 'react';
import SearchBar from '../../components/student/SearchBar';
import { AppContext } from '../../context/AppContext';
import { useParams } from 'react-router-dom';
import CourseCard from '../../components/student/CourseCard';
import { assets } from '../../assets/assets';
import Footer from '../../components/student/Footer';

const CoursesList = () => {
  const { navigate, allCourses } = useContext(AppContext);
  const { input } = useParams(); // Get the search input from the URL

  const [filteredCourses, setFilteredCourses] = useState([]);

  useEffect(() => {
    if (allCourses && allCourses.length > 0) {
      const tempCourses = [...allCourses]; // Create a copy of the courses array

      if (input) {
        // Filter courses based on the search input
        const lowerCaseInput = input.toLowerCase();
        const filtered = tempCourses.filter((course) =>
          course.courseTitle.toLowerCase().includes(lowerCaseInput)
        );
        setFilteredCourses(filtered);
      } else {
        // If no input, show all courses
        setFilteredCourses(tempCourses);
      }
    }
  }, [allCourses, input]); // Re-run when allCourses or input changes

  return (
 <>
    <div className="relative md:px-36 px-8 pt-20 text-left">
      <div className="flex md:flex-row flex-col gap-6 items-start justify-between w-full">
        <div>
          <h1 className="text-4xl font-semibold text-gray-800">Course List</h1>
          <p className="text-gray-500">
            <span
              className="text-blue-600 cursor-pointer"
              onClick={() => navigate('/')}
            >
              Home
            </span>{' '}
            / <span>Course List</span>
          </p>
        </div>
        <SearchBar data={input} />
      </div>
      {
        input &&  <div className='inline-flex items-center gap-4 px-4 py-2 border mt-8 -mb-8 text-gray-600 '>
          <p>{input}</p>
          <img src={assets.cross_icon} alt="" className='cursor-pointer' onClick={()=>{
            navigate('/course-list')
          }} />
        </div>
      }
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 my-16 gap-3 px-2 md:p-0">
        {filteredCourses.length > 0 ? (
          filteredCourses.map((course) => (
            <CourseCard key={course._id || course.name} course={course} />
          ))
        ) : (
          <p>No courses found.</p>
        )}
      </div>
    </div>
  <Footer/>
 </>
  );
};

export default CoursesList;