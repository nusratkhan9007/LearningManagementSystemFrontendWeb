import React from 'react'

const StudentsEnrolled = () => {
  return (
    <div>
        <h1>Students Enrolled page</h1>
    </div>
  )
}

export default StudentsEnrolled