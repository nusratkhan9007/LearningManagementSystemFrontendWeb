import React from 'react'

const AddCourse = () => {
  return (
    <div>
    <h1>Add Course </h1>
    </div>
  )
}

export default AddCourse