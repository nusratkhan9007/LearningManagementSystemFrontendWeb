import React from 'react'

const MyCourses = () => {
  return (
    <div>
        <h1>My Courses page</h1>
   </div>
  )
}

export default MyCourses